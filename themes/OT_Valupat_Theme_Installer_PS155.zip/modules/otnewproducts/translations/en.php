<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocknewproducts}prestashop>blocknewproducts_2bc4c1efe10bba9f03fac3c59b4d2ae9'] = 'Do not allow new products at this time.';
