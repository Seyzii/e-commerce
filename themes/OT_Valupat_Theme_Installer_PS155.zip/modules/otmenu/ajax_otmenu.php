<?php
/**
 # @package			Menu module for Prestashop 1.5
 # @sub_package		otmenu - Dropdown menu for Prestashop 1.5
 # @author			NetQ Creative Software
 # @copyright 		Copyright(C) 2012 NetQ Creative Software, QExtension.com & Omegatheme.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.qextensions.com
 # @support			http://www.qextensions.com/forum
**/
/**---------------------------------------------------------------------------
 * @file: ajax_otmenu.php 1.0 00001, Nov 2012 12:00:00Z QExtensions $
 * @desc: Ajax response for otmenu back-office
 *---------------------------------------------------------------------------*/
 
include_once('../../config/config.inc.php');
include_once('../../init.php');
include_once('otmenu.php');

$otmenu = new otmenu();
echo $otmenu->ajaxCallBackOffice();
