<?php
/**
 # @package			Menu module for Prestashop 1.5
 # @sub_package		otmenu - Dropdown menu for Prestashop 1.5
 # @author			NetQ Creative Software
 # @copyright 		Copyright(C) 2012 NetQ Creative Software, QExtension.com & Omegatheme.com. All Rights Reserved.
 # @license			GNU/GPL version 2 - http://www.gnu.org/licenses/gpl-2.0.html
 # @website			http://www.qextensions.com
 # @support			http://www.qextensions.com/forum
**/
/**---------------------------------------------------------------------------
 * @file: otmenu.php 1.5 00001, Nov 2012 12:00:00Z QExtensions $
 *---------------------------------------------------------------------------*/

class otmenu extends Module
{
	private $_menu = '';
	private $_html = '';
	private $_availableCMS = '';
	private $_availableCates = '';
	private $_availableProds = '';
	private $_availableItemsHtml = '';

	public function __construct()
	{
		$this->name = 'otmenu';
		$this->tab = 'front_office_features';
		$this->version = 1.5;
		$this->author = 'NetQ Creative Software';
		$this->need_instance = 0;

		parent::__construct();
		$this->displayName = $this->l('OT Dropdown Menu');
		$this->description = $this->l('Help add superfish dropdown menu to shop.');
		$this->secure_key = Tools::encrypt($this->name);
	}

	public function install()
	{
		if(!parent::install() ||
			!$this->installDB() ||
			!Configuration::updateValue('OTMENU_drop_layout', 'drop') ||
			!Configuration::updateValue('OTMENU_drop_effect', 'opacity_height') ||
			!Configuration::updateValue('OTMENU_drop_speed', 'normal') ||
			!Configuration::updateValue('OTMENU_drop_delay', 800) ||
			!Configuration::updateValue('OTMENU_drop_show_arrow', 1) ||
			!Configuration::updateValue('OTMENU_drop_enable_dropshadow', 0) ||
			!$this->registerHook('backOfficeHeader') ||
			!$this->registerHook('header') ||
			!$this->registerHook('menuBar') 
			/* 
			!$this->registerHook('actionObjectCategoryUpdateAfter') ||
			!$this->registerHook('actionObjectCategoryDeleteAfter') ||
			!$this->registerHook('actionObjectCmsUpdateAfter') ||
			!$this->registerHook('actionObjectCmsDeleteAfter') ||
			!$this->registerHook('actionObjectSupplierUpdateAfter') ||
			!$this->registerHook('actionObjectSupplierDeleteAfter') ||
			!$this->registerHook('actionObjectManufacturerUpdateAfter') ||
			!$this->registerHook('actionObjectManufacturerDeleteAfter') ||
			!$this->registerHook('actionObjectProductUpdateAfter') ||
			!$this->registerHook('actionObjectProductDeleteAfter') ||
			!$this->registerHook('categoryUpdate')
			 */
			)
		  return false;
		return true;
	}

	public function installDb()
	{
		Db::getInstance()->ExecuteS('
		CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ot_menu` (
			`id_ot_menu` INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
			`id_shop` INT UNSIGNED NOT NULL,
			`name` VARCHAR( 255 ) NOT NULL,
			`link` VARCHAR( 255 ) NOT NULL,
			`parent` INT UNSIGNED NOT NULL,
			`target` VARCHAR( 50 ) NOT NULL,
			`publish` TINYINT( 1 ) NOT NULL,
			`order` INT( 2 ) NOT NULL,
			INDEX (`id_shop`)
		) ENGINE = '._MYSQL_ENGINE_.' CHARACTER SET utf8 COLLATE utf8_general_ci;');
		Db::getInstance()->ExecuteS('
		CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'ot_menu_lang` (
			`id_ot_menu` INT NOT NULL,
			`id_shop` INT UNSIGNED NOT NULL,
			`id_lang` INT NOT NULL,
			`name` VARCHAR( 255 ) NOT NULL,
			`link` VARCHAR( 255 ) NOT NULL,
			INDEX ( `id_ot_menu` , `id_lang`, `id_shop` )
		) ENGINE = '._MYSQL_ENGINE_.' CHARACTER SET utf8 COLLATE utf8_general_ci;');
		return true;
	}

	public function uninstall()
	{
		if(!parent::uninstall() ||
		   !$this->uninstallDB())
			return false;
		return true;
	}

	private function uninstallDb()
	{
		Db::getInstance()->ExecuteS('DROP TABLE `'._DB_PREFIX_.'ot_menu`');
		Db::getInstance()->ExecuteS('DROP TABLE `'._DB_PREFIX_.'ot_menu_lang`');
		return true;
	}

	public function getContent()
	{
		
    	global $cookie;
		$id_lang = (int)Context::getContext()->language->id;
		$id_shop = (int)((bool) Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE')) ? Context::getContext()->shop->id : 0;
		$languages = $this->context->controller->getLanguages();
		$defaultLanguage = (int)Configuration::get('PS_LANG_DEFAULT');
		$divLangName = 'name_label';
		
		$this->context->controller->addJS(_PS_JS_DIR_.'/jquery/ui/jquery.ui.core.min.js');
		$this->context->controller->addJS(_PS_JS_DIR_.'/jquery/ui/jquery.ui.widget.min.js');
		$this->context->controller->addJS(_PS_JS_DIR_.'/jquery/ui/jquery.ui.mouse.min.js');
		$this->context->controller->addJS(_PS_JS_DIR_.'/jquery/ui/jquery.ui.sortable.min.js');
		
		$this->_html .= '<h2>'.$this->l('OT Dropdown Menu').'</h2>';

		// Message
		if(!empty($this->_msg))
    	{
			if ($this->_msg[0] == 'error') $this->_html .= $this->displayError($this->_msg[1]);
			if ($this->_msg[0] == 'conf') $this->_html .= $this->displayConfirmation($this->_msg[1]);
    	}
		
    	if(Tools::isSubmit('submitBlockOTMenuLinks'))
    	{
      		if(Tools::getValue('name') == '')
      		{
        		$this->_html .= $this->displayError($this->l('Unable to add this menu link, please insert name and link'));
      		}
      		else
      		{
        		$this->add(Tools::getValue('name'), Tools::getValue('link'), Tools::getValue('parent', 0), Tools::getValue('target'), Tools::getValue('order', 0), Tools::getValue('publish', 1), $id_shop);
				$this->_html .= $this->displayConfirmation($this->l('The menu link has been added'));
      		}
			unset($_POST['itemType']);
    	}
    	if(Tools::isSubmit('submitBlockOTMenuRemove'))
    	{
      		$id_ot_menu = Tools::getValue('id_ot_menu', 0);
      		$this->remove($id_ot_menu, (int)Shop::getContextShopID());

      		$this->_html .= $this->displayConfirmation($this->l('The link has been removed'));
    	}

		if(Tools::isSubmit('submitBlockOTMenuEdit'))
    	{
      		$id_ot_menu = Tools::getValue('id_ot_menu', 0);
      		$ot_menu = $this->get($id_ot_menu, $defaultLanguage, $id_shop);
    	}

		if(Tools::isSubmit('submitBlockOTMenuEdited'))
    	{
      		$ot_menu = $this->edit(Tools::getValue('id_ot_menu_edit', 0), Tools::getValue('name'), Tools::getValue('link'), Tools::getValue('parent', 0), Tools::getValue('target'), Tools::getValue('order', 0), Tools::getValue('publish', 1), Tools::getValue('parent_old', 0), $id_shop);

      		$this->_html .= $this->displayConfirmation($this->l('The menu item has been edited'));
    	}


		if(Tools::isSubmit('submitBlockOTMenuConfig'))
    	{
			$dropdown_layout = Tools::getValue('dropdown_layout', 'drop');
			$dropdown_effect = Tools::getValue('dropdown_effect', 'opacity_height');
			$dropdown_speed = Tools::getValue('dropdown_speed', 'normal');
			$dropdown_delay = Tools::getValue('dropdown_delay', 800);
			$dropdown_show_arrow = Tools::getValue('dropdown_show_arrow', 1);
			$dropdown_enable_dropshadow = Tools::getValue('dropdown_enable_dropshadow', 0);

			if(
			!Configuration::updateValue('OTMENU_drop_layout', $dropdown_layout) ||
			!Configuration::updateValue('OTMENU_drop_effect', $dropdown_effect) ||
			!Configuration::updateValue('OTMENU_drop_speed', $dropdown_speed) ||
			!Configuration::updateValue('OTMENU_drop_delay', $dropdown_delay) ||
			!Configuration::updateValue('OTMENU_drop_show_arrow', $dropdown_show_arrow) ||
			!Configuration::updateValue('OTMENU_drop_enable_dropshadow', $dropdown_enable_dropshadow))
			{
				$this->_html .= $this->displayError($this->l('Configuration update failed!'));
			}
			else $this->_html .= $this->displayConfirmation($this->l('Configuration updated!'));
		}
		
		
		if(Tools::isSubmit('submitItemType')){
			if (Tools::getValue('itemType') != ''){
				switch (Tools::getValue('itemType')) {
					case 'Categories':
					{
						$this->_availableCates = '';
						$this->getCategoriesOption();
						$this->_availableItemsHtml = '<select id="availbleItems" name="availbleItems" size="10">'.$this->_availableCates.'</select>
						<input type="submit" name="submitSelectElement" value="'.$this->l('Select').'" class="button"/>';
						break;
					}
					case 'Products':
					{
						$this->_availableProds = '';
						$this->getProductsOption();
						$this->_availableItemsHtml = '<select id="availbleItems" name="availbleItems" size="10">'.$this->_availableProds.'</select>
						<input type="submit" name="submitSelectElement" value="'.$this->l('Select').'" class="button"/>';
						break;
					}
					case 'CMS':
					{
						$this->_availableCMS = '';
						$this->getCMSOption();
						$this->_availableItemsHtml = '<select id="availbleItems" name="availbleItems" size="10">'.$this->_availableCMS.'</select>
						<input type="submit" name="submitSelectElement" value="'.$this->l('Select').'" class="button"/>';
						break;
					}
					case 'Supplier':
					{
						$SuppliersOptionHtml = $this->getSuppliersOption();
						$this->_availableItemsHtml = '<select id="availbleItems" name="availbleItems" size="10">'.$SuppliersOptionHtml.'</select>
						<input type="submit" name="submitSelectElement" value="'.$this->l('Select').'" class="button"/>';
						break;
					}
					case 'Manufacturer':
					{
						$ManufacturersOptionHtml = $this->getManufacturersOption();
						$this->_availableItemsHtml = '<select id="availbleItems" name="availbleItems" size="10">'.$ManufacturersOptionHtml.'</select>
						<input type="submit" name="submitSelectElement" value="'.$this->l('Select').'" class="button"/>';
						break;
					}
				}
			}
		}
		
		
		if(Tools::isSubmit('submitSelectElement')){
			if (Tools::getValue('availbleItems') != ''){
				$theNewLink = '';
				switch (Tools::getValue('itemType')) {
					case 'Categories':
					{
						$id_category = str_replace('CAT', '', Tools::getValue('availbleItems'));
						$category = new Category((int)$id_category, (int)$id_lang);

						if ($category->level_depth > 1)
							$theNewLink = $category->getLink();
						else
							$theNewLink = $this->context->link->getPageLink('index');
						break;
					}
					case 'Products':
					{
						
						$id_product = str_replace('PRD', '', Tools::getValue('availbleItems'));
						$product = new Product((int)$id_product, true, (int)$id_lang);
						$theNewLink = $product->getLink();
						break;
					}
					case 'CMS':
					{
						
						if (strpos(Tools::getValue('availbleItems'), 'CMS_CAT') !== false)
						{
							$cmsCateId = str_replace('CMS_CAT', '', Tools::getValue('availbleItems'));

							$cmsCate = new CMSCategory((int)$cmsCateId, (int)$id_lang);
							$theNewLink = $cmsCate->getLink();
						}
						else {
							$cmsId = str_replace('CMS', '', Tools::getValue('availbleItems'));
							$cmsPage = CMS::getLinks((int)$id_lang, array($cmsId));
							$theNewLink = @$cmsPage[0]['link'];
						}

						break;
					}
					case 'Supplier':
					{
						
						$supid = str_replace('SUP', '', Tools::getValue('item'));
						$supplier = new Supplier((int)$supid, (int)$id_lang);
						if (!is_null($supplier->id))
						{
							$link = new Link;
							$theNewLink = $link->getSupplierLink((int)$supid, $supplier->link_rewrite);
						}

						break;
					}
					case 'Manufacturer':
					{
						
						$manid = str_replace('MAN', '', Tools::getValue('item'));
						$manufacturer = new Manufacturer((int)$manid, (int)$id_lang);
						if (!is_null($manufacturer->id))
						{
							if (intval(Configuration::get('PS_REWRITING_SETTINGS')))
								$manufacturer->link_rewrite = Tools::link_rewrite($manufacturer->name, false);
							else
								$manufacturer->link_rewrite = 0;
							$link = new Link;
							$theNewLink = $link->getManufacturerLink((int)$manid, $manufacturer->link_rewrite);
						}

						break;
					}
				}

				$theNewLink = Tools::str_replace_once(Context::getContext()->shop->getBaseURL(), '', $theNewLink);
				//echo Tools::htmlentitiesUTF8($theNewLink);
				//echo $theNewLink;
			}
		}
		
   		$this->_html .= '
   		<fieldset>
      		<legend><img src="../img/admin/add.gif" alt="" title="" />'.$this->l('Add/Edit Menu Item').'</legend>
      			<form method="POST" action="'.Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']).'">
					<div class="form-wrapper">
						<div class="menu-item-type">
							<span>'.$this->l('Choose menu item type').'</span>
							<div class="form">';
							$this->_html .= $this->displaySelectboxMenuType(Tools::getValue('itemType'));
							$this->_html .= '<input type="submit" name="submitItemType" value="'.$this->l('Go').'" class="button"/>';
							$this->_html .= '</div>';
							$this->_html .= '<p class="clear"> </p>

							<div class="form">
								<div id="availPointingItems">'.$this->_availableItemsHtml.'</div>
								
							</div>';
							$this->_html .= '<p class="clear"> </p>
						</div>
						<div class="menu-item-form">
						';
							foreach ($languages as $language)
							{
								$this->_html .= '
								<div class="item-form-wrap" id="name_label_'.$language['id_lang'].'" style="display: '.($language['id_lang'] == $defaultLanguage ? 'block' : 'none').';float: left;">
								
									<label>'.$this->l('Name').'</label>
									<div class="form">
										<input type="text" name="name['.$language['id_lang'].']" id="name_'.$language['id_lang'].'" size="70" value="';
										if(@$ot_menu[0]['id_ot_menu']) {
											$langName = $this->getName($language['id_lang'],@$ot_menu[0]['id_ot_menu']);
											$this->_html .= $langName[0]['name'];
										}
										$this->_html .= '" />';
									$this->_html .= '</div>
									';
									$this->_html .= '
										<label>'.$this->l('Link').'</label>
										<div class="form">
											<input type="text" name="link['.$language['id_lang'].']" id="link_'.$language['id_lang'].'" class="input-item-link" size="70" value="';
											if(@$ot_menu[0]['id_ot_menu']) {
												$langLink = $this->getLink($language['id_lang'],@$ot_menu[0]['id_ot_menu']);
											}
											$this->_html .= isset($theNewLink) ? $theNewLink : @$langLink[0]['link'];											
											$this->_html .= '" />';
										$this->_html .= '</div>
								</div>';
							}
							$this->_html .= $this->displayFlags($languages, $defaultLanguage, $divLangName, 'name_label', true);

							
							
							$this->_html .= '<p class="clear"> </p>
							<label>'.$this->l('Target').'</label>
							<div class="form">
								<select name="target">
									<option>none</option>
									<option value="_blank"';
									if(@$ot_menu[0]['target']=='_blank') {
										$this->_html .= ' SELECTED';
									}
									$this->_html .= '>_blank</option>
									<option value="_parent"';
									if(@$ot_menu[0]['target']=='_parent') {
										$this->_html .= ' SELECTED';
									}
									$this->_html .= '>_parent</option>
									<option value="_self"';
									if(@$ot_menu[0]['target']=='_self') {
										$this->_html .= ' SELECTED';
									}
									$this->_html .= '>_self</option>
									<option value="_top"';
									if(@$ot_menu[0]['target']=='_top') {
										$this->_html .= ' SELECTED ';
									}
									$this->_html .= '>_top</option>
								</select>
							</div>
							<label>'.$this->l('Parent').'</label>
							<div class="form">
								<select name="parent">
									<option value=0> Root level </option>';

								$this->_html .= $this->displaySelectboxMenu(@$ot_menu[0]['parent']);

								$this->_html .= '</select>
							</div>
							<label>'.$this->l('Publish').'</label>
							<div class="form">';
							if(@$ot_menu[0]['publish'] or !@$ot_menu[0]['id_ot_menu']) {
								$this->_html .= '<input type="radio" name="publish" value="1" checked /><img title="Enabled" alt="Enabled" src="../img/admin/enabled.gif"/>
									<input type="radio" name="publish" value="0" /><img title="Disabled" alt="Disabled" src="../img/admin/disabled.gif"/>';
							}
							else {
								$this->_html .= '<input type="radio" name="publish" value="1" /><img title="Enabled" alt="Enabled" src="../img/admin/enabled.gif"/>
									<input type="radio" name="publish" value="0" checked /><img title="Disabled" alt="Disabled" src="../img/admin/disabled.gif"/>';
							}
							$this->_html .= '
							</div>
							<label>'.$this->l('Order').'</label>
							<div class="form">
								<input type="text" name="order" value="'.@$ot_menu[0]['order'].'" size="10" />
							</div>
							<p class="center"> ';
							if(!@$ot_menu[0]['id_ot_menu']) {
								$this->_html .= '
								<input type="submit" name="submitBlockOTMenuLinks" value="'.$this->l('  Add  ').'" class="button" /> ';
							}
							else {
								$this->_html .= '<input type="hidden" name="id_ot_menu_edit" value="'.@$ot_menu[0]['id_ot_menu'].'" />
								<input type="hidden" name="parent_old" value="'.@$ot_menu[0]['parent'].'" />
								<input type="submit" name="submitBlockOTMenuEdited" value="'.$this->l('  Save  ').'" class="button" />
								<input type="reset" name="resetBlockOTMenuEdited" value="'.$this->l('  Reset  ').'" class="button" />';
							}
							$this->_html .= '</p>
						</div>
					</div>
				</form>
			</fieldset><br />';

		$this->_html .= '
		<fieldset>
			<legend>
				<span onclick="$(\'#menu_items_list_wrapper\').slideToggle()" style="cursor:pointer">
					<img src="../img/admin/add.gif" alt="'.$this->l('Menu items').'" class="middle" />
				</span>
				<img src="../img/admin/details.gif" alt="details" title="details" />'.$this->l('Menu items').'
			</legend>
			<div id="menu_items_list_wrapper" class="togle_block">
				<table style="width:100%;" class="table" id="ot-menu-tablednd">
					<thead>
						<tr>
							<th align="center">'.$this->l('Id').'</th>
							<th>'.$this->l('Name').'</th>
							<th>'.$this->l('Link').'</th>
							<th>'.$this->l('Target').'</th>
							<th align="center">'.$this->l('Order').'</th>
							<th align="center">'.$this->l('Publish').'</th>
							<th align="center">'.$this->l('Action').'</th>
						</tr>
					</thead>
					<tbody>';
					$this->_html .=  $this->displayBOMenuItemList();
					$this->_html .= '</tbody>
				</table>
			</div>
		</fieldset><br />';

		$this->_html .= '
		<fieldset>
			<legend>
				<span onclick="$(\'#menu_items_sort_wrapper\').slideToggle()" style="cursor:pointer">
					<img src="../img/admin/add.gif" alt="'.$this->l('Re-sort menu items').'" class="middle" />
				</span>
				<img src="../img/admin/summary.png" alt="details" title="details" />'.$this->l('Re-sort menu items').'
			</legend>
			<div id="menu_items_sort_wrapper" class="togle_block">
				<div class="warn"><img src="../img/admin/warn2.png">&nbsp;&nbsp;Hold and drag icon to sort the menu items. Click "'.$this->l('Update order').'" button when done.</div>
				<p style="text-align:right;"><input type="button" id="save_order" class="button" name="save_order" value="'.$this->l('Update order').'"/></p>
				<div id="sortinfo"></div>
					<div id="linklist_wrapper">';
					$this->_html .=  $this->displayMenuSort();
					$this->_html .= '
					</div>
			</div>
		</fieldset><br />';

		$this->_html .= '
		<fieldset>
			<legend>
				<span onclick="$(\'#menu_config_wrapper\').slideToggle()" style="cursor:pointer">
					<img src="../img/admin/add.gif" alt="'.$this->l('Menu Configurations').'" class="middle" />
				</span>
				<img src="../img/admin/cog.gif" alt="details" title="details" />'.$this->l('Menu Configurations').'
			</legend>
			<div id="menu_config_wrapper" class="togle_block">
				<form method="POST" action="'.Tools::htmlentitiesUTF8($_SERVER['REQUEST_URI']).'">';
					$this->_html .=  $this->displayMenuConfig();
					$this->_html .= '
				</form>
			</div>
		</fieldset><br />';


		$this->_html .= '<script type="text/javascript">
				
				function selectElement(){
					var itemType = $("#itemType :selected").val();
					var item = $("#availbleItems :selected").val();
					if (item == "") return false;
					$.ajax({
						type: "POST",
						url: "' . __PS_BASE_URI__ . 'modules/otmenu/ajax_otmenu.php",
						data: "action=getItemLink&itemType="+itemType+"&item="+item+"&secure_key='.$this->secure_key.'",
						dataType: "text",
						async : false,
						success: function(msg){
							//$("#link_"+id_language).attr("value",msg);
							$(".item-form-wrap").filter(":visible").eq(0).find(".input-item-link").attr("value", msg);
						}
					});
					return false;
				}
				
				$(document).ready(function() {
					$(".togle_block").hide();
					
					/* 
					$("#itemType").change(function(){
						var itemType = $("#itemType :selected").val();
						if (itemType == "" || itemType == "Custom") return;
						$.ajax({
							type: "POST",
							url: "' . __PS_BASE_URI__ . 'modules/otmenu/ajax_otmenu.php",
							data: "action=getPointingItems&itemType="+itemType+"&secure_key='.$this->secure_key.'",
							dataType: "html",
							async : false,
							success: function(msg){
								$("#availPointingItems").html(msg);
							}
						});
					});
					 */

					$("#save_order").click(function(){
						var order = "";
						$("#linklist_wrapper .ui-sortable").each(function(index){
							order += $(this).sortable("serialize")+"&";
						});

						$.ajax({
							type: "POST",
							url: "' . __PS_BASE_URI__ . 'modules/otmenu/ajax_otmenu.php",
							data: order+"action=saveorder&secure_key='.$this->secure_key.'",
							dataType: "html",
							async : false,
							success: function(msg){
								$("#sortinfo").html(msg);
								$("#sortinfo").fadeIn(500);
								setTimeout(function(){ $("#sortinfo").fadeOut(1000) }, 5000);
								//location.reload();
								window.location.href = window.location.href;

							}
						});
					});
				});
			</script>';

		return $this->_html;

	}

	private function gets($id_lang, $id_ot_menu = null, $publish = null, $id_shop)
	{
		$id_shop = (int)((bool) Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE')) ? $id_shop : 0;
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		return Db::getInstance()->ExecuteS('
		SELECT l.`id_ot_menu`, l.`target`, ll.`link`, ll.`name`, l.`parent`, l.`order`, l.`publish`
		FROM `'._DB_PREFIX_.'ot_menu` l
		LEFT JOIN `'._DB_PREFIX_.'ot_menu_lang` ll ON (l.`id_ot_menu` = ll.`id_ot_menu` AND ll.`id_lang` = "'.$id_lang.'") WHERE 1=1
		'.((!is_null($id_ot_menu)) ? 'AND l.`id_ot_menu` = "'.$id_ot_menu.'"' : '').'
		'.((!is_null($publish)) ? 'AND l.`publish` = "'.$publish.'"' : '').' 
		AND l.id_shop IN (0, '.(int)$id_shop.')
		Order by `parent`, `order`
		');
	}

	private function get($id_ot_menu, $id_lang, $id_shop)
	{
		return self::gets($id_lang, $id_ot_menu, null, $id_shop);
	}

	private function getsListMenus($id_lang, $parent = 0)
	{
		$menus = array();
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		$id_shop = (int)((bool) Configuration::get('PS_MULTISHOP_FEATURE_ACTIVE')) ? Context::getContext()->shop->id : 0;
		$ot_menuLinks = Db::getInstance()->ExecuteS('
		SELECT l.`id_ot_menu`, l.`target`, ll.`link`, ll.`name`, l.`parent`, l.`order`, l.`publish`
		FROM `'._DB_PREFIX_.'ot_menu` l
		LEFT JOIN `'._DB_PREFIX_.'ot_menu_lang` ll ON (l.`id_ot_menu` = ll.`id_ot_menu` AND ll.`id_lang` = '.(int)$id_lang.') 
		WHERE l.`parent` = '. (int)$parent .' 
		'.($id_shop > 0 ? 'AND l.`id_shop` IN (0, '.(int)$id_shop.')' : '').
		'Order by `order`');

		$i = 0;
		foreach($ot_menuLinks as $ot_menuLink) {
		  $menus[$i] = $ot_menuLink;
		  $menus[$i]['subitems'] = self::getsListMenus($id_lang, $ot_menuLink['id_ot_menu']);
		  $i++;
		}
		return $menus;
	}

	private function getName($id_lang, $id_ot_menu, $id_shop)
	{
		return Db::getInstance()->ExecuteS('
		SELECT ll.`name`
		FROM `'._DB_PREFIX_.'ot_menu` l
		LEFT JOIN `'._DB_PREFIX_.'ot_menu_lang` ll ON (l.`id_ot_menu` = ll.`id_ot_menu` AND ll.`id_lang` = "'.$id_lang.'") WHERE 1=1 
		AND l.`id_shop` IN (0, '.(int)$id_shop.') 
		'.((!is_null($id_ot_menu)) ? 'AND l.`id_ot_menu` = "'.$id_ot_menu.'"' : '').'
		');
	}

	private function getLink($id_lang, $id_ot_menu, $id_shop)
	{
		return Db::getInstance()->ExecuteS('
		SELECT `link`
		FROM `'._DB_PREFIX_.'ot_menu_lang`
		WHERE `id_ot_menu` = '.(int)$id_ot_menu.' AND `id_lang` = '.(int)$id_lang.' AND `id_shop` IN (0, '.(int)$id_shop.')
		');
	}

	private function add($name, $link, $parent = 0, $target, $order = 0, $publish = 1, $id_shop)
	{
		if(!is_array($name) || !is_array($link))
		  return false;
		
		Db::getInstance()->insert(
			'ot_menu',
			array(
				'parent'=> (int)$parent,
				'id_shop' => (int)$id_shop,
				'target'=> $target,
				'publish'=> (int)$publish,
				'order'=> (int)$order
			)
		);

		// Insert ID
		$id_ot_menu = Db::getInstance()->Insert_ID();

		// Add data on ot_menu_lang table
		foreach($name as $id_lang=>$lname)
		{
		  Db::getInstance()->insert(
			'ot_menu_lang',
			array(
			  'id_ot_menu'=>$id_ot_menu,
			  'id_lang'=>$id_lang,
			  'id_shop'=>(int)$id_shop,
			  'name'=>pSQL($lname),
			  'link'=>pSQL($link[$id_lang])
			)
		  );
		}

	}


	private function edit($id_ot_menu, $name, $link, $parent = 0, $target, $order = 0, $publish = 1, $parent_old, $id_shop)
	{
		if(!is_array($name) || !is_array($link))
			return false;
		
		// Update menu item on ot_menu table
		Db::getInstance()->update(
			'ot_menu',
			array(
				'parent'=> (int)$parent,
				'id_shop' => (int)$id_shop,
				'target'=> $target,
				'publish'=> (int)$publish,
				'order'=> (int)$order
			),
			'id_ot_menu = '.(int)$id_ot_menu
		);
		
		// Check parent
		$parent_parent = Db::getInstance()->ExecuteS('SELECT `parent` FROM `'._DB_PREFIX_.'ot_menu` WHERE `id_ot_menu` = '.$parent);

		if($parent_parent[0]['parent'] == $id_ot_menu) {
			Db::getInstance()->update(
				'ot_menu',
				array(
					'parent'=> 0
				),
				'id_ot_menu = '.(int)$parent
			);
		}
		
		// Update menu item on ot_menu_lang table
		foreach($name as $id_lang=>$lname) {
			Db::getInstance()->update(
				'ot_menu_lang',
				array(
					'id_shop'=>(int)$id_shop,
					'name'=>pSQL($lname),
					'link'=>pSQL($link[$id_lang])
				),
				'`id_ot_menu` = '.(int)$id_ot_menu.' AND `id_lang` = '.(int)$id_lang
			);
		}
		
	}

	/*
	* 
	*/
	private function remove($id_ot_menu, $id_shop)
	{
		if ($ip_shop > 0){
			Db::getInstance()->delete(_DB_PREFIX_.'ot_menu', '`id_ot_menu` = '.(int)$id_ot_menu.' AND `id_shop` = '.(int)$id_shop);
		}else{
			Db::getInstance()->delete(_DB_PREFIX_.'ot_menu', '`id_ot_menu` = '.(int)$id_ot_menu);
		}
		Db::getInstance()->delete(_DB_PREFIX_.'ot_menu_lang', '`id_ot_menu` = '.(int)$id_ot_menu);
		Db::getInstance()->update(
			'ot_menu',
			array(
				'parent'=> 0
			),
			'`parent` = '.(int)$id_ot_menu
		);
	}

	private function displaySelectboxMenuType($defaultValue = 0)
	{
    	global $cookie;
  		$listOption = '';
  		$listOption .= '<select name="itemType" id="itemType">
							<option value="">&nbsp;'.$this->l('Select menu item type').'&nbsp;</option>
							<option value="CMS" '.($defaultValue == 'CMS' ? ' SELECTED ' : '').'>&nbsp;'.$this->l('Display CMS Category or CMS page').'&nbsp;</option>
							<option value="Categories" '.($defaultValue == 'Categories' ? ' SELECTED ' : '').'>&nbsp;'.$this->l('Display Product Categories').'&nbsp;</option>
							<option value="Products" '.($defaultValue == 'Products' ? ' SELECTED ' : '').'>&nbsp;'.$this->l('Display a Product').'&nbsp;</option>
							<option value="Supplier" '.($defaultValue == 'Supplier' ? ' SELECTED ' : '').'>&nbsp;'.$this->l('Display Supplier').'&nbsp;</option>
							<option value="Manufacturer" '.($defaultValue == 'Manufacturer' ? ' SELECTED ' : '').'>&nbsp;'.$this->l('Display Manufacturer').'&nbsp;</option>
							<option value="Custom" '.($defaultValue == 'Custom' ? ' SELECTED ' : '').'>&nbsp;'.$this->l('Custom link').'&nbsp;</option>
						</select>';
		return $listOption;
	}

 	private function displaySelectboxMenu($defaultValue = 0, $parent = 0, $pretext = '')
	{
    	global $cookie;
		$id_lang = (int)Context::getContext()->language->id;
  		$listOption = '';
		$pretext .= '-';
  		$ot_menulinks = $this->getsListMenus($id_lang, $parent);
		foreach ($ot_menulinks as $ot_menulink) {
			$listOption .= '<option value="'.$ot_menulink['id_ot_menu'].'"';

			// Select default value
			if($defaultValue == $ot_menulink['id_ot_menu']) {
				$listOption .= ' SELECTED ';
			}

			$listOption .= '> '. $pretext . $ot_menulink['name'].' </option>';
			if($ot_menulink['subitems'])
				$listOption .= $this->displaySelectboxMenu($defaultValue, $ot_menulink['id_ot_menu'], $pretext);
		}
		return $listOption;
	}

	/*
	* Display menu item list for sorting
	*/
	private function displayMenuSort($parent = 0, $pretext = '')
	{
    	global $cookie;
		
		$id_lang = (int)Context::getContext()->language->id;
		
  		$listField = '';
		if($parent) $pretext = '&nbsp;&nbsp;&nbsp;&nbsp;' . $pretext . '--';

  		$ot_menulinks = $this->getsListMenus($id_lang, $parent);

		$listField .= '<ul id="linklist_'.$parent.'" parentid="'.$parent.'" style="list-style: none; background: #FFF;">';
		foreach ($ot_menulinks as $indx => $ot_menulink) {
			$adcls = ($indx % 2) ? '' : 'alt_row';
			$listField .= '<li id="linkid['.$parent.']_'.$ot_menulink['id_ot_menu'].'" class="alt_row" style="padding:0; border-top: 1px dashed #E0D0B1;">';
			$listField .= '<div style="padding: 8px 4px;">';
			$listField .= '<img width="16" height="16" class="handle" alt="move" src="'.$this->_path.'img/arrow.png" style="cursor: move; padding: 0 8px 0 2px;">';
			$listField .= '<strong>'.$ot_menulink['name']. '</strong>&nbsp;&nbsp;&nbsp;&nbsp;( <em><strong>id</strong>: '.$ot_menulink['id_ot_menu'] .'</em>, <em><strong>Link</strong>: '. $ot_menulink['link'].'</em> )';

			$listField .= '</div>';
			if($ot_menulink['subitems'])
				$listField .= $this->displayMenuSort($ot_menulink['id_ot_menu'], $pretext);


			$listField .= '</li>';
		}
		$listField .= '</ul>';

		$listField .= '
						<input type="hidden" name="parentid" value="'.$parent.'" />
						<input type="hidden" name="linkitemid" value="" />';

		$listField .= '
		<script type="text/javascript">
			$(document).ready(function() {
				$("#linklist_'.$parent.'").sortable({
				  handle : ".handle",
				  update : function () {
					/* var order = $("#linklist_'.$parent.'").sortable("serialize");
					$("#sortinfo").load("'.$_SERVER['REQUEST_URI'].'&action=sortajax&parent='.$parent.'"+order);
					$("#sortinfo").text(order); */
				  }
				});
			});
		</script>';

		return $listField;
	}

	/*
	* Display menu item list in BO
	*/
	private function displayBOMenuItemList($parent = 0, $pretext = '')
	{
    	global $cookie;
		
		$id_lang = (int)Context::getContext()->language->id;
		$defaultLanguage = (int)Configuration::get('PS_LANG_DEFAULT');
  		$listField = '';
		if($parent) $pretext = '&nbsp;&nbsp;&nbsp;&nbsp;' . $pretext . '--';
  		$ot_menulinks = $this->getsListMenus($defaultLanguage, $parent);

		foreach ($ot_menulinks as $ot_menulink) {
			$listField .= '<tr id="rowid-'.$ot_menulink['id_ot_menu'].'">';
			$listField .= '<td align="center">'. $ot_menulink['id_ot_menu'].'</td>';
			$listField .= '<td>'. $pretext . $ot_menulink['name'].'</td>';
			$listField .= '<td>'. $ot_menulink['link'].'</td>';
			$listField .= '<td>'. $ot_menulink['target'].'</td>';
			$listField .= '<td align="center">'. $ot_menulink['order'].'</td>';
			$listField .= '<td align="center">';
				if($ot_menulink['publish']) $listField .= '<img title="Enabled" alt="Enabled" src="../img/admin/enabled.gif"/>';
				else $listField .= '<img title="Disabled" alt="Disabled" src="../img/admin/disabled.gif"/>';
			$listField .= '</td>';
			$listField .= '<td align="center"> <form action="'.$_SERVER['REQUEST_URI'].'" method="post">
                <input type="hidden" name="id_ot_menu" value="'.$ot_menulink['id_ot_menu'].'" />
				<button name="submitBlockOTMenuEdit" class="button"><img src="../img/admin/edit.gif" alt="Edit" title="Edit" /></button>
				<button name="submitBlockOTMenuRemove" class="button" onclick="javascript:return confirm(\''.$this->l('Are you sure you want to remove this link?').'\');" ><img src="../img/admin/delete.gif" alt="Delete" title="Delete" /></button>

          		</form></td>';
			$listField .= '</tr>';
			if($ot_menulink['subitems'])
				$listField .= $this->displayBOMenuItemList($ot_menulink['id_ot_menu'], $pretext);

		}
		return $listField;
	}

	private function displayListMenu($parent = 0, $class = 'ot-list')
	{
    	global $cookie;
		$id_lang = (int)Context::getContext()->language->id;
		$id_lang_default = (int)Configuration::get('PS_LANG_DEFAULT');

		// current link
		$curent_link = str_replace(__PS_BASE_URI__, '', $_SERVER["REQUEST_URI"]);

  		$listMenus = '<ul id="ot-menu-'. $parent .'" class="'. $class .'">';
  		$ot_menulinks = $this->getsListMenus($id_lang, $parent);

		$countLink = 0;

		foreach ($ot_menulinks as $ot_menulink) {
			$countLink++;
			$li_class = '';
			$curentclass = '';

			// class for <li>
			if ($countLink==1) $li_class .= ' first ';
			elseif ($countLink==count($ot_menulinks)) $li_class .= ' last ';
			else $li_class .= '';

			// active class
			if(($ot_menulink['link']==$curent_link) or ($curent_link==NULL and $ot_menulink['link']=='index.php')) {
				$li_class .= ' li-current ';
				$curentclass .= 'class="selected active"';
			}

			// items
			$listMenus .= '<li class="'. $li_class .' ot_number_'. $countLink .'">';
			$target = '';
			if ($ot_menulink['target'] != 'none')
				$target = 'target = "'.$ot_menulink['target'] .'"';
			$listMenus .= '<a href="'. (@substr_compare($ot_menulink['link'], 'http://', 0, 7) ? __PS_BASE_URI__ : '') . $ot_menulink['link'] .'" '.$target.' title="'. $ot_menulink['name'] .'" '. $curentclass .'><span>'. $ot_menulink['name'].'</span>';
			$listMenus .= '</a>';

			// submenu
			if($ot_menulink['subitems'])
				$listMenus .= $this->displayListMenu($ot_menulink['id_ot_menu']);

			$listMenus .= '</li>';
		}

		$listMenus .= '</ul>';

		return $listMenus;
	}

	public function displayMenuConfig()
	{
		$html = '';

		$html .= '
			<label>'.$this->l('Dropdown layout').'</label>
			<div class="margin-form">
				<select name="dropdown_layout" id="dropdown_layout">
					<option value="drop" '.(Configuration::get('OTMENU_drop_layout') == 'drop' ? 'selected="selected"' : '').'> &nbsp;'.$this->l('Default dropdown').'&nbsp;</option>
					<option value="drop_bar" '.(Configuration::get('OTMENU_drop_layout') == 'drop_bar' ? 'selected="selected"' : '').'> &nbsp;'.$this->l('Dropdown with second navbar').'&nbsp;</option>
				</select>
			</div>
			<label>'.$this->l('Dropdown effect type').'</label>
			<div class="margin-form">
				<select name="dropdown_effect" id="dropdown_effect">
					<option value="opacity" '.(Configuration::get('OTMENU_drop_effect') == 'opacity' ? 'selected="selected"' : '').'> &nbsp;'.$this->l('Fade-in').'&nbsp;</option>
					<option value="height" '.(Configuration::get('OTMENU_drop_effect') == 'height' ? 'selected="selected"' : '').'> &nbsp;'.$this->l('Slide-down').'&nbsp;</option>
					<option value="opacity_height" '.(Configuration::get('OTMENU_drop_effect') == 'opacity_height' ? 'selected="selected"' : '').'> &nbsp;'.$this->l('Fade-in and Slide-down').'&nbsp;</option>
				</select>
			</div>
			<label>'.$this->l('Dropdown speed').'</label>
			<div class="margin-form">
				<select name="dropdown_speed" id="dropdown_speed">
					<option value="slow" '.(Configuration::get('OTMENU_drop_speed') == 'slow' ? 'selected="selected"' : '').'> &nbsp;'.$this->l(' Slow ').'&nbsp;</option>
					<option value="normal" '.(Configuration::get('OTMENU_drop_speed') == 'normal' ? 'selected="selected"' : '').'> &nbsp;'.$this->l(' Normal ').'&nbsp;</option>
					<option value="fast" '.(Configuration::get('OTMENU_drop_speed') == 'fast' ? 'selected="selected"' : '').'> &nbsp;'.$this->l(' Fast ').'&nbsp;</option>
				</select>
			</div>
			<label>'.$this->l('Dropdown delay').'</label>
			<div class="margin-form">
				<input type="text" name="dropdown_delay" id="dropdown_delay" size="30" value="'.(int)(Configuration::get('OTMENU_drop_delay')).'" /><br />'
				.$this->l('Delay in miliseconds. Default is 800').'
			</div>
			<label>'.$this->l('Automatically arrow mark-up').'</label>
			<div class="margin-form">
				<img src="../img/admin/enabled.gif" alt="Yes" title="Yes" />
		        <input type="radio" name="dropdown_show_arrow" id="dropdown_show_arrow_yes" value="1" '.((int)(Configuration::get('OTMENU_drop_show_arrow')) == 1 ? 'checked="checked"' : '').'/>
			    <label class="t" for="dropdown_show_arrow_yes">'.$this->l('Yes').'</label>
			    <img src="../img/admin/disabled.gif" alt="No" title="No" style="margin-left: 10px;" />
			    <input type="radio" name="dropdown_show_arrow" id="dropdown_show_arrow_no" value="0" '.((int)(Configuration::get('OTMENU_drop_show_arrow')) == 0 ? 'checked="checked"' : '').'/>
			    <label  class="t" for="dropdown_show_arrow_no">'.$this->l('No').'</label><br />'
				.$this->l('Automatically generate parent menu item arrow mark-up. Default is "Yes"').'
			</div>
			<label>'.$this->l('Drop shadow and rounded up').'</label>
			<div class="margin-form">
				<img src="../img/admin/enabled.gif" alt="Yes" title="Yes" />
		        <input type="radio" name="dropdown_enable_dropshadow" id="dropdown_enable_dropshadow_yes" value="1" '.((int)(Configuration::get('OTMENU_drop_enable_dropshadow')) == 1 ? 'checked="checked"' : '').'/>
			    <label class="t" for="dropdown_enable_dropshadow_yes">'.$this->l('Yes').'</label>
			    <img src="../img/admin/disabled.gif" alt="No" title="No" style="margin-left: 10px;" />
			    <input type="radio" name="dropdown_enable_dropshadow" id="dropdown_enable_dropshadow_no" value="0" '.((int)(Configuration::get('OTMENU_drop_enable_dropshadow')) == 0 ? 'checked="checked"' : '').'/>
			    <label  class="t" for="dropdown_enable_dropshadow_no">'.$this->l('No').'</label><br />'
				.$this->l('Show shadow and rounded for sub-level &lt;ul&gt;. Default is "No"').'
			</div>
			<div class="margin-form">
				<br />
				<input type="submit" name="submitBlockOTMenuConfig" value="'.$this->l('  Save  ').'" class="button" />
			</div>';

		return $html;

	}

	public function ajaxCallBackOffice()
	{
		global $cookie;


		if (!Tools::isSubmit('secure_key') OR Tools::getValue('secure_key') != $this->secure_key OR !Tools::isSubmit('action'))
			die(1);
		
		switch (Tools::getValue('action'))
		{
			case 'saveorder':
			{
				$linkids = array();
				$linkids = Tools::getValue('linkid');
				$html = '';
				$success = false;
				foreach($linkids as $parentid => $linkchildids){
					foreach($linkchildids as $order => $linkchildid){
						Db::getInstance()->Execute('
							UPDATE `'._DB_PREFIX_.'ot_menu`
							SET `order` = '.(int)($order+1).'
							WHERE `id_ot_menu` = '.(int)$linkchildid);

					}
				}
				$success = true;

				$html .= ($success === true) ? '<div class="conf">'.$this->l('Order updated!').'</div>' : '<div class="error">'.$this->l('Order update failed!').'</div>';

				return $html;
				break;
			}

			case 'getPointingItems':
			{
				switch (Tools::getValue('itemType')) {
					case 'Categories':
					{
						$this->_availableCates = '';
						$this->getCategoriesOption();
						return '<select id="availbleItems" name="availbleItems" size="10">'.$this->_availableCates.'</select>
						<a id="selectElement" class="button" href="javascript: void(0);" onclick="javascript: selectElement();" title="'.$this->l('Select').'">'.$this->l('Select').'</a>';
						break;
					}
					case 'Products':
					{
						$this->_availableProds = '';
						$this->getProductsOption();
						return '<select id="availbleItems" name="availbleItems" size="10">'.$this->_availableProds.'</select>
						<a id="selectElement" class="button" href="javascript: void(0);" onclick="javascript: selectElement();" title="'.$this->l('Select').'">'.$this->l('Select').'</a>';
						break;
					}
					case 'CMS':
					{
						$this->_availableCMS = '';
						$this->getCMSOption();
						return '<select id="availbleItems" name="availbleItems" size="10">'.$this->_availableCMS.'</select>
						<a id="selectElement" class="button" href="javascript: void(0);" onclick="javascript: selectElement();" title="'.$this->l('Select').'">'.$this->l('Select').'</a>';
						break;
					}
					case 'Supplier':
					{
						$SuppliersOptionHtml = $this->getSuppliersOption();
						return '<select id="availbleItems" name="availbleItems" size="10">'.$SuppliersOptionHtml.'</select>
						<a id="selectElement" class="button" href="javascript: void(0);" onclick="javascript: selectElement();" title="'.$this->l('Select').'">'.$this->l('Select').'</a>';
						break;
					}
					case 'Manufacturer':
					{
						$ManufacturersOptionHtml = $this->getManufacturersOption();
						return '<select id="availbleItems" name="availbleItems" size="10">'.$ManufacturersOptionHtml.'</select>
						<a id="selectElement" class="button" href="javascript: void(0);" onclick="javascript: selectElement();" title="'.$this->l('Select').'">'.$this->l('Select').'</a>';
						break;
					}
				}

				break;
			}
			
			case 'getItemLink':
			{
				$theNewLink = '';
				switch (Tools::getValue('itemType')) {
					case 'Categories':
					{
						
						$id_category = str_replace('CAT', '', Tools::getValue('item'));
						$category = new Category((int)$id_category, (int)$id_lang);

						if ($category->level_depth > 1)
							$theNewLink = $category->getLink();
						else
							$theNewLink = $this->context->link->getPageLink('index');
						break;
					}
					case 'Products':
					{
						
						$id_product = str_replace('PRD', '', Tools::getValue('item'));
						$product = new Product((int)$id_product, true, (int)$id_lang);
						$theNewLink = $product->getLink();
						break;
					}
					case 'CMS':
					{
						
						if (strpos(Tools::getValue('item'), 'CMS_CAT') !== false)
						{
							$cmsCateId = str_replace('CMS_CAT', '', Tools::getValue('item'));

							$cmsCate = new CMSCategory((int)$cmsCateId, (int)$id_lang);
							$theNewLink = $cmsCate->getLink();
						}
						else {
							$cmsId = str_replace('CMS', '', Tools::getValue('item'));
							$cmsPage = CMS::getLinks((int)$id_lang, array($cmsId));
							$theNewLink = @$cmsPage[0]['link'];
						}

						break;
					}
					case 'Supplier':
					{
						
						$supid = str_replace('SUP', '', Tools::getValue('item'));
						$supplier = new Supplier((int)$supid, (int)$id_lang);
						if (!is_null($supplier->id))
						{
							$link = new Link;
							$theNewLink = $link->getSupplierLink((int)$supid, $supplier->link_rewrite);
						}

						break;
					}
					case 'Manufacturer':
					{
						
						$manid = str_replace('MAN', '', Tools::getValue('item'));
						$manufacturer = new Manufacturer((int)$manid, (int)$id_lang);
						if (!is_null($manufacturer->id))
						{
							if (intval(Configuration::get('PS_REWRITING_SETTINGS')))
								$manufacturer->link_rewrite = Tools::link_rewrite($manufacturer->name, false);
							else
								$manufacturer->link_rewrite = 0;
							$link = new Link;
							$theNewLink = $link->getManufacturerLink((int)$manid, $manufacturer->link_rewrite);
						}

						break;
					}
				}

				$theNewLink = Tools::str_replace_once(Context::getContext()->shop->getBaseURL(), '', $theNewLink);
				//echo Tools::htmlentitiesUTF8($theNewLink);
				return $theNewLink;
				break;
			}
		}


	}

	private function getCMSOption($parent = 0, $depth = 1, $id_lang = false)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;

		$categories = $this->getCMSCategories(false, (int)$parent, (int)$id_lang);
		$pages = $this->getCMSPages((int)$parent, false, (int)$id_lang);

		$spacer = str_repeat('-- ', 1 * (int)$depth);

		foreach ($categories as $category)
		{
			$this->_availableCMS .= '<option value="CMS_CAT'.$category['id_cms_category'].'" '.(('CMS_CAT'.$category['id_cms_category'] == Tools::getValue('availbleItems')) ? 'selected="selected"' : '').' style="font-weight: bold;">'.$spacer.$category['name'].'</option>';
			$this->getCMSOption($category['id_cms_category'], (int)$depth + 1, (int)$id_lang);
		}

		foreach ($pages as $page)
			$this->_availableCMS .= '<option value="CMS'.$page['id_cms'].'" '.(('CMS'.$page['id_cms'] == Tools::getValue('availbleItems')) ? 'selected="selected"' : '').'>'.$spacer.$page['meta_title'].'</option>';
	}

	private function getCMSCategories($recursive = false, $parent = 1, $id_lang = false)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;

		if ($recursive === false)
		{
			$sql = 'SELECT bcp.`id_cms_category`, bcp.`id_parent`, bcp.`level_depth`, bcp.`active`, bcp.`position`, cl.`name`, cl.`link_rewrite`
				FROM `'._DB_PREFIX_.'cms_category` bcp
				INNER JOIN `'._DB_PREFIX_.'cms_category_lang` cl
				ON (bcp.`id_cms_category` = cl.`id_cms_category`)
				WHERE cl.`id_lang` = '.(int)$id_lang.'
				AND bcp.`id_parent` = '.(int)$parent;

			return Db::getInstance()->executeS($sql);
		}
		else
		{
			$sql = 'SELECT bcp.`id_cms_category`, bcp.`id_parent`, bcp.`level_depth`, bcp.`active`, bcp.`position`, cl.`name`, cl.`link_rewrite`
				FROM `'._DB_PREFIX_.'cms_category` bcp
				INNER JOIN `'._DB_PREFIX_.'cms_category_lang` cl
				ON (bcp.`id_cms_category` = cl.`id_cms_category`)
				WHERE cl.`id_lang` = '.(int)$id_lang.'
				AND bcp.`id_parent` = '.(int)$parent;

			$results = Db::getInstance()->executeS($sql);
			foreach ($results as $result)
			{
				$sub_categories = $this->getCMSCategories(true, $result['id_cms_category'], (int)$id_lang);
				if ($sub_categories && count($sub_categories) > 0)
					$result['sub_categories'] = $sub_categories;
				$categories[] = $result;
			}

			return isset($categories) ? $categories : false;
		}

	}

	private function getCMSPages($id_cms_category, $id_shop = false, $id_lang = false)
	{
		$id_shop = ($id_shop !== false) ? (int)$id_shop : (int)Context::getContext()->shop->id;
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;

		$sql = 'SELECT c.`id_cms`, cl.`meta_title`, cl.`link_rewrite`
			FROM `'._DB_PREFIX_.'cms` c
			INNER JOIN `'._DB_PREFIX_.'cms_shop` cs
			ON (c.`id_cms` = cs.`id_cms`)
			INNER JOIN `'._DB_PREFIX_.'cms_lang` cl
			ON (c.`id_cms` = cl.`id_cms`)
			WHERE c.`id_cms_category` = '.(int)$id_cms_category.'
			AND cs.`id_shop` = '.(int)$id_shop.'
			AND cl.`id_lang` = '.(int)$id_lang.'
			AND c.`active` = 1
			ORDER BY `position`';

		return Db::getInstance()->executeS($sql);
	}

	private function getProductsOption($id_lang = false)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		$products = Product::getSimpleProducts($id_lang);
		
		if (count($products) > 0) {
			foreach ($products as $product)
				$this->_availableProds .= '<option value="PRD'.(int)$product['id_product'].'" '.(('PRD'.(int)$product['id_product'] == Tools::getValue('availbleItems')) ? 'selected="selected"' : '').'>&nbsp;'.$product['name'].'&nbsp;</option>';
		}
		else {
			$this->_availableProds .= $this->l('No porduct available!');
		}
	}
	
	private function getCategoriesOption($id_category = 1, $id_lang = false, $id_shop = false, $recursive = true, $default = null)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		$category = new Category((int)$id_category, (int)$id_lang, (int)$id_shop);

		if (is_null($category->id))
			return;

		if ($recursive)
		{
			$children = Category::getChildren((int)$id_category, (int)$id_lang, true, (int)$id_shop);
			$spacer = str_repeat('-- ', 1 * (int)$category->level_depth);
		}

		$shop = (object) Shop::getShop((int)$category->getShopID());
		$this->_availableCates .= '<option value="CAT'.(int)$category->id.'" '.(('CAT'.(int)$category->id == Tools::getValue('availbleItems')) ? 'selected="selected"' : '').'>'.(isset($spacer) ? $spacer : '').$category->name.' ('.$shop->name.')</option>';

		if (isset($children) && count($children))
			foreach ($children as $child)
			{
				$this->getCategoriesOption((int)$child['id_category'], (int)$id_lang, (int)$child['id_shop']);
			}

	}

	private function getSuppliersOption($id_lang = false)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		$spacer = '&nbsp;';
		$suppliersHtml = '';
		$suppliers = Supplier::getSuppliers(false, $id_lang);
		foreach ($suppliers as $supplier) {
			$suppliersHtml .= '<option value="SUP'.$supplier['id_supplier'].'" '.(('SUP'.$supplier['id_supplier'] == Tools::getValue('availbleItems')) ? 'selected="selected"' : '').'>'.$spacer.$supplier['name'].$spacer.'</option>';
		}
		return $suppliersHtml;
	}

	private function getManufacturersOption($id_lang = false)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		$spacer = '&nbsp;';
		$manufacturersHtml = '';

		$manufacturers = Manufacturer::getManufacturers(false, $id_lang);
		foreach ($manufacturers as $manufacturer) {
			$manufacturersHtml .= '<option value="MAN'.$manufacturer['id_manufacturer'].'" '.(('MAN'.$manufacturer['id_manufacturer'] == Tools::getValue('availbleItems')) ? 'selected="selected"' : '').'>'.$spacer.$manufacturer['name'].$spacer.'</option>';
		}
		return $manufacturersHtml;
	}

	private function getCategory($id_category, $id_lang = false, $id_shop = false)
	{
		$id_lang = $id_lang ? (int)$id_lang : (int)Context::getContext()->language->id;
		$category = new Category((int)$id_category, (int)$id_lang);

		if ($category->level_depth > 1)
			$category_link = $category->getLink();
		else
			$category_link = $this->context->link->getPageLink('index');

		if (is_null($category->id))
			return;

		$children = Category::getChildren((int)$id_category, (int)$id_lang, true, (int)$id_shop);
		$selected = ($this->page_name == 'category' && ((int)Tools::getValue('id_category') == $id_category)) ? ' class="sfHoverForce"' : '';

		$is_intersected = array_intersect($category->getGroups(), $this->user_groups);
		// filter the categories that the user is allowed to see and browse
		if (!empty($is_intersected))
		{
			$this->_menu .= '<li '.$selected.'>';
			$this->_menu .= '<a href="'.$category_link.'">'.$category->name.'</a>';

			if (count($children))
			{
				$this->_menu .= '<ul>';

				foreach ($children as $child)
					$this->getCategory((int)$child['id_category'], (int)$id_lang, (int)$child['id_shop']);

				$this->_menu .= '</ul>';
			}
			$this->_menu .= '</li>';
		}
	}


	public function hookBackOfficeHeader()
	{
		// add css and js to BO header
		return '
		<style type="text/css">
			.ui-sortable-helper {
				border: 1px dashed #FF0000;
			}
			#menu_items_sort_wrapper ul {
				padding-left: 30px;
			}
			.menu-item-type {
				float: left;
				width:35%;
			}
			div.form {
				padding: 0 0 1em  0;
			}
			.menu-item-form {
				float: left;
				width: 65%;
			}
			.menu-item-form label {
				text-align: left;
				width: auto;
			}
		</style>';
	}

	public function hookHeader($param)
	{
		$this->context->controller->addCSS($this->_path.'css/otmenu.css', 'all');
		$this->context->controller->addJS($this->_path.'js/hoverIntent.js');
		$this->context->controller->addJS($this->_path.'js/superfish.js');

		$dropdown_effect = Configuration::get('OTMENU_drop_effect');
		$dropdown_speed = Configuration::get('OTMENU_drop_speed');
		$dropdown_delay = Configuration::get('OTMENU_drop_delay');
		$dropdown_show_arrow = Configuration::get('OTMENU_drop_show_arrow');
		$dropdown_enable_dropshadow = Configuration::get('OTMENU_drop_enable_dropshadow');

		switch ($dropdown_effect) {
			case 'opacity':
				$dropdown_effect = 'opacity:"show"';
			break;

			case 'height':
				$dropdown_effect = 'height:"show"';
			break;

			case 'opacity_height':
				$dropdown_effect = 'opacity:"show",height:"show"';
			break;

			default:
				$dropdown_effect = 'opacity:"show",height:"show"';
			break;
		}

		return '
		<script type="text/javascript">
			$(document).ready(function() {
				$("ul.dropdown").superfish({
					delay:       '.$dropdown_delay.',
					animation:   {'.$dropdown_effect.'},
					speed:       "'.$dropdown_speed.'",
					autoArrows:  '.$dropdown_show_arrow.',
					dropShadows: '.$dropdown_enable_dropshadow.'
				});
			});
		</script>
		';
	}

	public function hookMenuBar($param)
	{
		global $smarty;

		$dropdown_layout = Configuration::get('OTMENU_drop_layout');
		switch ($dropdown_layout) {
			case 'drop':
				$dropdown_layout = 'dropdown';
			break;

			case 'drop_bar':
				$dropdown_layout = 'dropdown drop-navbar';
			break;

			default:
				$dropdown_layout = 'dropdown';
			break;
		}

		$this->_menu = $this->displayListMenu(0, 'ot-menu '.$dropdown_layout);
		$smarty->assign('MENU', $this->_menu);
    	return $this->display(__FILE__, 'otmenu.tpl');
	}

	public function hookDisplayTop($params)
	{
		return $this->hookMenuBar($params);
	}

	public function hookDisplayLeftColumn($params)
	{
		global $smarty;
		$this->_menu = $this->displayListMenu(0, 'ot-menu nav-vertical');
		$smarty->assign('MENU', $this->_menu);
    	return $this->display(__FILE__, 'otmenu.tpl');
	}

	public function hookDisplayRightColumn($params)
	{
		return $this->hookDisplayLeftColumn($params);
	}

	/*
	// Currently no cache controll
	public function hookActionObjectCategoryUpdateAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectCategoryDeleteAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectCmsUpdateAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectCmsDeleteAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectSupplierUpdateAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectSupplierDeleteAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectManufacturerUpdateAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectManufacturerDeleteAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectProductUpdateAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookActionObjectProductDeleteAfter($params)
	{
		$this->clearMenuCache();
	}

	public function hookCategoryUpdate($params)
	{
		$this->clearMenuCache();
	}

	private function clearMenuCache()
	{
		$this->_clearCache('otmenu.tpl');
	}
	*/

}
?>