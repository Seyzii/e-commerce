<?php 
	if (!defined('_PS_VERSION_'))
	exit;
	class ottemcontrol extends Module{
	
		public function __construct(){
			$this->name = 'ottemcontrol';
			$this->tab = 'front_office_features';
			$this->version = 1.5;
			$this->author = 'NetQ Creative Software';
			$this->need_instance = 0;
	 
			parent::__construct();
	 
			$this->displayName = $this->l('OT Theme Control Panel');
			$this->description = $this->l('OT Theme Control Panel.');
		}
		
		public function getContent(){
			$output = '<h2>'.$this->displayName.'</h2>';
			if (Tools::isSubmit('submit') )
			{
				
				$_width = (Tools::getValue('width'));	
				Configuration::updateValue('width',$_width);

				$_layout = (Tools::getValue('layout'));	
				Configuration::updateValue('layout',$_layout);

				$_custom_tpl = (Tools::getValue('custom_tpl'));	
				Configuration::updateValue('custom_tpl',$_custom_tpl);
				
				$LayoutStyle = (Tools::getValue('LayoutStyle'));	
				Configuration::updateValue('Otcontrol_LayoutStyle',$LayoutStyle);
			}
			return $output.$this->displayForm();
		}
		
		public function displayForm(){
			$custom_tpl = Configuration::get('custom_tpl', 'off');
			$custom_layout = Configuration::get('layout', 'leftContent');
			$_widththeme = Configuration::get('width',$_width);
			$output = '
			
			<form action="'.$_SERVER['REQUEST_URI'].'" method="post">
			<fieldset><legend><img src="'.$this->_path.'logo.gif" alt="" title="" />'.$this->l('Settings').'</legend>
			<label>'.$this->l('Custom Template').'</label>
			<div class="margin-form">
					<input type="radio" name="custom_tpl" value="on" '.($custom_tpl == 'on' ? 'checked="checked"' : '').' />
					<label class="t" for="display_on"> <img src="../img/admin/enabled.gif" alt="'.$this->l('Enabled').'" title="'.$this->l('Enabled').'" /></label>
					<input type="radio" name="custom_tpl" value="off" '.($custom_tpl != 'on' ? 'checked="checked"' : '').' default="1" />
					<label class="t" for="display_off"> <img src="../img/admin/disabled.gif" alt="'.$this->l('Disabled').'" title="'.$this->l('Disabled').'" /></label>
					<p class="clear">'.$this->l('Allow  The  Custom Template').'</p>
			</div>
			<label>'.$this->l('Template Width').'</label>
			<div class="margin-form">
				<input name="width" site="30" value="'.($_widththeme !='' ? Tools::getValue('width', Configuration::get('width')) : '960px').'" />
				<p class="clear">'.$this->l('Default Template Width : 960px').'</p>
			</div>
			<label>'.$this->l('Default Layout Type').'</label>
			<div class="margin-form">
				<select name="layout" style="width:150px;" default="contentRight">
					<option value="leftcontent" '.($custom_layout == 'leftcontent' ? 'selected="selected"' : '').'>'.$this->l("Left - Content").'</option>
					<option value="contentRight" '.($custom_layout == 'contentRight' ? 'selected="selected"' : '').'>'.$this->l("Content - Right").'</option>
				</select>
			</div>
			<center><input type="submit" name="submit" value="'.$this->l('Update').'" class="button" /></center>
			</fieldset>
			</fieldset>
			</form>
			
			<style>
				label.control_on, label.control_off {
					float: none;
					text-align: left;
					width: auto;
				}
				
			</style>
			';
			return $output;
		}
		
		
		public function install(){
				if(!parent::install()){
					return false;
				}
			if(parent::install() == false)
				return false;
			return true;
		}
		public function uninstall(){
			if (!parent::uninstall())
			Db::getInstance()->Execute('DELETE FROM `'._DB_PREFIX_.'ottemcontrol`');
			parent::uninstall();
		}
		
	}
?>